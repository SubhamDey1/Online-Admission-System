<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
<link href="styles.css" rel="stylesheet" type="text/css"> </link>
</head>
<body>
<div class="page">
<div class="headerpart">
 <h1> RASTRA GURU SURENDRANATH COLLEGE OF ENGINEERING </h1>
  <p>Approved By AICTE,Bangalore</p>
  <img src="image/logo.jpg">
</div>
<div class="root">
<marquee direction="left"> <p>Admissions 2019-20</p> <p> Academic Enrichment Program -“Nanoscience and Technology: Trends and Challenges”</p></marquee>
</div>
<div class="linkpart">
<center>
<ol>
<li><a href="page.php">HOME</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="img.php">PHOTOS</a></li>
<li><a href="index.php">ADMISSION</a></li>
<li><a href="dept.php">DEPARTMENT</a></li>
<li><a href="cse.php">FACULTY</a></li>
<li><a href="placement.php">PLACEMENT</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ol>
</div>
<div class="loc">
<h1>CONTACT US</h1></br>
<p><b>Dr. K. N. Subramanya</b></br>
Principal</br></br>
R.V.College of Engineering</br></br>
Phone: 91-080-67178000 / 8021 / 8020</br></br>
Fax: 91-080-6717 8011<p>
<h3>If you have any questions regarding education or course details, please contact us by calling or e-mailing us and we'll get back to you as soon as possible.

</br></br>We look forward to hearing from you.</h3>
<h4><b>R G S College of Engineering</b></br></br>
Mysuru Road Bengaluru - 560 059</br></br>
Ph : 91 - 080-6717 8000 / 8021 / 8020</br></br>
Fax: 91 - 080-6717 8011</br></br>
Email : principalrgsce@gmail.com
</h4>
<iframe frameborder="0" height="500px" scrolling="no" src="https://maps.google.com/?ie=UTF8&amp;ll=12.923633,77.499619&amp;spn=0.010373,0.013797&amp;t=h&amp;z=16&amp;output=embed" 
width="800px">
</iframe>
</div>
</html>