 <html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
</head>
<body>
<div class="page">
<div class="headerpart">
 <h1> RASTRA GURU SURENDRANATH COLLEGE OF ENGINEERING </h1>
  <p>Approved By AICTE,Bangalore</p> 
 <img src="image/logo.jpg">
</div>
<div class="root">
<marquee direction="left"> <p>Admissions 2019-20</p> <p> Academic Enrichment Program -“Nanoscience and Technology: Trends and Challenges”</p></marquee>
</div>
<div class="linkpart">
<center>
<ol>
<li><a href="page.php">HOME</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="img.php">PHOTOS</a></li>
<li><a href="index.php">ADMISSION</a></li>
<li><a href="dept.php">DEPARTMENT</a></li>
<li><a href="cse.php">FACULTY</a></li>
<li><a href="placement.php">PLACEMENT</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ol>
</div>
<div class="newspart">
<h2>NOTICE BOARD</h2>
<center>
<li><a href="#">Rotostat services privet limited on </a></li>
<li><a href="#"><b>Rotostat services privet limited on </b></a></li>
<li><a href="#">Rotostat services privet limited on </a></li>
<li><a href="#"><b>Rotostat services privet limited on </b></a></li>
<li><a href="#">Rotostat services privet limited on </a></li>
<li><a href="#"><b>Rotostat services privet limited on </b></a></li>
<li><a href="#">Rotostat services privet limited on </a></li>
<li><a href="#"><b>Rotostat services privet limited on</b> </a></li></marquee>
</div>
<div class="bodypart">
<div class="slider">
</div>
<div class="rock">
<center>
<h2>RASTRA GURU SURENDRANATH COLLEGE OF ENGINEERING</h1>
</center>
<h3>Established in 2004 with seven engineering branches namely Civil, Mechanical,Electrical,ELECTRONICS,INFORMATION,COMPUTER,CHEMICAL
 today RGSCE offers 12 Under Graduate Engineering programmes, 21 Master Degree programmes and Doctoral Studies
 .Located 13 km from the heart of Bangalore City – the Silicon Valley of India, on Mysore Road.Sprawling campus
 spread over an area of 52 acres set in sylvan surroundings.Provides an ideal ambience to stimulate the teaching-learning
 process, helping in bringing out skilled and disciplined Engineers. Rated one amongst the top ten self-financing Engineering 
 Institutions in the country. Current annual student intake for Undergraduate Programmes & Post Graduate Programmes in Engineering
 is in excess of 1200. Highly qualified and dedicated faculty.<br>
 Utilizes its expertise in various disciplines to conduct Research and Development for Industry and Defense establishments in the country.

</div>
</div>
<div class="rk">
<a href="#"><img src="image/fb.png"></a>
<a href="#"><img src="image/tw.jpg"></a>
<a href="#"><img src="image/ml.png"></a>
<a href="#"><img src="image/u.gif"><a>
<center>
<p>rakesh subham rima</p>
</div>
</div>
</body>
</html>