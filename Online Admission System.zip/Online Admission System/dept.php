 <html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
</head>
<body>
<div class="page">
<div class="headerpart">
 <h1> RASTRA GURU SURENDRANATH COLLEGE OF ENGINEERING </h1>
  <p>Approved By AICTE,Bangalore</p> 
 <img src="image/logo.jpg">
</div>
<div class="root">
<marquee direction="left"> <p>Admissions 2019-20</p> <p> Academic Enrichment Program -“Nanoscience and Technology: Trends and Challenges”</p></marquee>
</div>
<div class="linkpart">
<center>
<ol>
<li><a href="page.php">HOME</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="img.php">PHOTOS</a></li>
<li><a href="index.php">ADMISSION</a></li>
<li><a href="dept.php">DEPARTMENT</a></li>
<li><a href="cse.php">FACULTY</a></li>
<li><a href="placement.php">PLACEMENT</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ol>
</div>
<div class="dep">
<h1><u>Faculty Council of Engineering & Technology</u></h1>
<h2>Vision :</h2>
<p>To provide young minds an ambience and quality education in Engineering and Technology to contribute towards a better world.</p>
 
<h2>Mission :</h2>
<ul>
<li>To nurture Engineering and Technological potential in undergraduate and post graduate students at their highest standard;</li>
<li>To take up technological challenges of the State, Nation and beyond for ensuring social security and sustainable development;</li>
<li>To provide infrastructure at par with international standard for quality training, research and development;</li>
<li>To encourage collaborative activities across disciplines to take up global challenges;</li>
<li>To enable young learners with legal and ethical awareness to meet challenges in Industry and academics or for setting up start-up ventures.</li>
</ul>
</br>
<ol>
<b><li>Chemical Engineering</li>
<li>Civil Engineering</li>
<li>Computer Science & Engineering</li>
<li>Electrical Engineering</li>
<li>Electronics & Telecommunication Engineering</li>
<li>Information Technology</li>
<li>Mechanical Engineering</li>
<li>Power Engineering</li>
<li>Printing Engineering</li>
</b></ol>
</div>
<div class="dpt">
<h1>rakesh kayal</h1>
</div>
</html>