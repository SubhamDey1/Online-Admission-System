<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
<link href="styles.css" rel="stylesheet" type="text/css"> </link>
</head>
<body>
<div class="page">
<div class="headerpart"> 
 <h1> RASTRA GURU SURENDRANATH COLLEGE OF ENGINEERING </h1>
  <p>Approved By AICTE,Bangalore</p>

 <img src="image/logo.jpg">
</div>
<div class="root">
<marquee direction="left"> <p>Admissions 2019-20</p> <p> Academic Enrichment Program -“Nanoscience and Technology: Trends and Challenges”</p></marquee>
</div>
<div class="linkpart">
<center>
<ol>
<li><a href="page.php">HOME</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="img.php">PHOTOS</a></li>
<li><a href="index.php">ADMISSION</a></li>
<li><a href="dept.php">DEPARTMENT</a></li>
<li><a href="cse.php">FACULTY</a></li>
<li><a href="placement.php">PLACEMENT</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ol>
</div>
<div class="pic">
<div class="gallery">
  <a target="_blank" href="image/1.jpg">
    <img src="image/1.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="image/2.jpg">
    <img src="image/2.jpg" alt="Forest" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="image/3.jpg">
    <img src="image/3.jpg" alt="Northern Lights" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/4.jpg">
    <img src="image/4.jpg" alt="Mountains" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/5.jpg">
    <img src="image/5.jpg" alt="Forest" width="600" height="100">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/6.jpg">
    <img src="image/6.jpg" alt="Forest" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/7.jpg">
    <img src="image/7.jpg" alt="Forest" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/8.jpg">
    <img src="image/8.jpg" alt="Forest" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/9.jpg">
    <img src="image/9.jpg" alt="Forest" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/184.jpg">
    <img src="image/184.jpg" alt="Forest" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/183.jpg">
    <img src="image/183.jpg" alt="Forest" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="image/182.jpg">
    <img src="image/182.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
<div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
<div class="gallery">
  <a target="_blank" href="image/180.jpg">
    <img src="image/180.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
<div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
 <div class="gallery">
  <a target="_blank" href="image/181.jpg">
    <img src="image/181.jpg" alt="Forest" width="600" height="400">
  </a>
 </div>
</div>
</body>
</html>