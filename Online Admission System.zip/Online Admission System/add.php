<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"> </link>
<link href="styles.css" rel="stylesheet" type="text/css"> </link>
</head>
<body>
	<form  action="index.php" method="post">
<div class="page">
<div class="headerpart">
 <h1> RASTRA GURU SURENDRANATH COLLEGE OF ENGINEERING </h1>
  <p>Approved By AICTE,Bangalore</p>
 <img src="image/logo.jpg">
</div>
<div class="linkpart">
<center>
<ol>
<li><a href="page.php">HOME</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="img.php">PHOTOS</a></li>
<li><a href="index.php">ADMISSION</a></li>
<li><a href="dept.php">DEPARTMENT</a></li>
<li><a href="cse.php">FACULTY</a></li>
<li><a href="placement.php">PLACEMENT</a></li>
<li><a href="contact.php">CONTACT</a></li>
</ol>
</div> 


</form>